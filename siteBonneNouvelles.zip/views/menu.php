<div id="navigation">
	<ul>
		<li><a href="index.php?action=genese">La genèse</a></li>
		<li><a href="index.php?action=livres">Les livres</a></li>
		<li><a href="index.php?action=contact">Contactez-nous</a></li>		
	</ul>
</div><!-- menu -->